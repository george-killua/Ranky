object Versions {
    //https://github.com/google/dagger
    const val Dagger = "2.40.5"
    //https://github.com/bumptech/glide
    const val Glide = "4.12.0"
    const val Kotlin = "1.6.10"
    const val Moshi = "1.13.0"
    const val OkHttp = "4.9.3"
    const val Retrofit = "2.9.0"
    const val Room = "2.4.0"
    const val RxJava3 = "3.1.0"
    const val LifecycleVersion = "2.4.0"
   // https://developer.android.com/guide/navigation/navigation-pass-data
    const val NavVersion = "2.5.0-alpha01"
}