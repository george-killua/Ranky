package com.killua.domain

import androidx.annotation.StringRes
import com.killua.data.IDatasourceRepo
import com.killua.data.models.Club
import com.killua.data.utils.RepoResult
import io.reactivex.rxjava3.core.Observable
import javax.inject.Inject

class GetAndCheckClubsUseCaseImpl @Inject constructor(
    private val dataSource: IDatasourceRepo
) : GetAndCheckClubsUseCase {
    override fun invoke(
        @StringRes database_error: Int,
        @StringRes insert_failure: Int,
        @StringRes remove_failure: Int
    ): Observable<RepoResult<List<Club>>> =
        dataSource.getAndCheckClubs(database_error, insert_failure, remove_failure)
}