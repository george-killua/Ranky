package com.killua.domain

interface DisposeUseCase {
    operator fun invoke(): Unit
}