package com.killua.domain

import androidx.annotation.StringRes
import com.killua.data.models.Club
import com.killua.data.utils.RepoResult
import io.reactivex.rxjava3.core.Observable

interface GetAndCheckClubsUseCase {
    operator fun invoke( @StringRes database_error: Int,
                         @StringRes insert_failure: Int,
                         @StringRes remove_failure: Int): Observable<RepoResult<List<Club>>>
}

