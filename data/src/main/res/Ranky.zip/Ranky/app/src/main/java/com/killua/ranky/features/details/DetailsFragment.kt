package com.killua.ranky.features.details

import android.os.Bundle
import android.view.View
import com.bumptech.glide.Glide
import com.killua.data.models.Club
import com.killua.ranky.R
import com.killua.ranky.base.BaseFragment
import com.killua.ranky.databinding.FragmentDetailsBinding
import com.zhuinden.fragmentviewbindingdelegatekt.viewBinding

class DetailsFragment : BaseFragment(R.layout.fragment_details) {


    private lateinit var viewModel: DetailsViewModel

    private val binding by viewBinding(FragmentDetailsBinding::bind)
    private val image by lazy {
        binding.ivClubImage
    }
    private val description by lazy {
        binding.tvDescription
    }
    private val countryName by lazy {
        binding.tvCountry
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = fragmentViewModel()
        viewModel.clubLiveData.observe(viewLifecycleOwner) {
            onSubmitClub(it)
        }
    }

    private fun onSubmitClub(club: Club) {
        Glide.with(this)
            .load(club.image)
            .centerCrop()
            .placeholder(R.drawable.ic_launcher_background)
            .into(image)
        description.text = getString(R.string.description_text, club.name, club.country, club.value)
        countryName.text = club.country

    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.dispose()
    }
    fun onClick(view: View) {
        //val action = SpecifyAmountFragmentDirections.actionSpecifyAmountFragmentToConfirmationFragment()
      //  view.findNavController().navigate(action)
    }
}