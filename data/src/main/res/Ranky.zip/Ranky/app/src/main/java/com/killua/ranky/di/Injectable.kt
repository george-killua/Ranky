package com.killua.ranky.di

/**
 * Marks an activity / fragment to be injected with Dagger
 *
 * @see AppInjector
 */
interface Injectable
