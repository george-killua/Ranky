package com.killua.ranky.features.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.killua.data.models.Club
import com.killua.data.utils.Exp.messageRes
import com.killua.data.utils.RepoResult
import com.killua.domain.DisposeUseCase
import com.killua.domain.GetAndCheckClubsUseCase
import com.killua.ranky.R
import io.reactivex.rxjava3.schedulers.Schedulers
import javax.inject.Inject

class MainViewModel @Inject constructor(
    val getandcheck: GetAndCheckClubsUseCase,
    val disposeUseCase: DisposeUseCase
) : ViewModel() {
    private val _clubsLiveData = MutableLiveData<RepoResult<List<Club>>>()
    val clubsLiveData: LiveData<RepoResult<List<Club>>>
        get() = _clubsLiveData

    private val _error = MutableLiveData<Int>()
    val error: LiveData<Int>
        get() = _error

    fun getClub(clubId: String) {
        getandcheck.invoke(R.string.database_error, R.string.insert_faild, R.string.remove_faild)
            .subscribeOn(Schedulers.trampoline())
            .doOnNext {
                _clubsLiveData.value = it
            }.doOnError {
                _error.value = it.messageRes
            }
            .observeOn(Schedulers.io())
    }

    fun dispose() = disposeUseCase.invoke()

}