package com.killua.ranky.features.main

import android.os.Bundle
import android.view.View
import com.killua.ranky.R
import com.killua.ranky.base.BaseFragment
import com.killua.ranky.databinding.FragmentMainBinding
import com.zhuinden.fragmentviewbindingdelegatekt.viewBinding

class MainFragment : BaseFragment(R.layout.fragment_main) {

    private val binding by viewBinding(FragmentMainBinding::bind)

    private lateinit var viewModel: MainViewModel



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = fragmentViewModel()

    }

}