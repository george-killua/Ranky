package com.killua.ranky

import android.os.Bundle
import com.killua.ranky.base.BaseActivity

class MainActivity  : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }
}