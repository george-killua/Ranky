package com.killua.data.networking

data class Location(
    val lat: Double,
    val lng: Double
)