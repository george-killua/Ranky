package com.killua.data.utils

object Exp {
    object ApiGettingError : Exception()
    object DatabaseIsEmpty : Exception()
    object DatabaseLoadError : Exception()
    object FailedInsertDatabase : Exception()
    object DatabaseInsertError : Exception()
    object DatabaseRemovingError : Exception()
    object DatabaseUpdatingError : Exception()
    object DatabaseNeedToUpdate : Exception()

    var Throwable.messageRes: Int
        get() = messageRes
        set(value) {
            messageRes = value
        }


}