package com.killua.data.networking

import io.reactivex.rxjava3.core.Single
import retrofit2.http.GET

interface ClubsServices {
    @GET
    fun getAllClubs(): Single<List<ClubApi>>
}
