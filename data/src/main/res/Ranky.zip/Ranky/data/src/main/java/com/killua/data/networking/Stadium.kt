package com.killua.data.networking

data class Stadium(
    val name: String,
    val size: Int
)