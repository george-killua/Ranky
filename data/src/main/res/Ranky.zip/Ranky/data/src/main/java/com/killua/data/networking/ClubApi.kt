package com.killua.data.networking

import com.killua.data.models.Club

data class ClubApi(
    val country: String,
    val european_titles: Int,
    val id: String,
    val image: String,
    val location: Location,
    val name: String,
    val stadium: Stadium,
    val value: Int
)

fun ClubApi.toClub(): Club {
    return Club(country, european_titles, id, image, name, value)
}