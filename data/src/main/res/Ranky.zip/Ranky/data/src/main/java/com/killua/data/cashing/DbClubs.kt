package com.killua.data.cashing

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(entities = [ClubsEntity::class], version = 1, exportSchema = false)
@TypeConverters(*arrayOf(Converters::class))
abstract class DbClubs : RoomDatabase() {
    abstract fun clubsDao(): ClubsDao
}

