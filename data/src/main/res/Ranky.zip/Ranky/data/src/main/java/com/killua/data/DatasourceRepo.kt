package com.killua.data

import androidx.annotation.StringRes
import com.killua.data.cashing.ClubsDao
import com.killua.data.cashing.ClubsEntity
import com.killua.data.cashing.toClub
import com.killua.data.cashing.toEntity
import com.killua.data.models.Club
import com.killua.data.networking.ClubsServices
import com.killua.data.networking.toClub
import com.killua.data.utils.Exp
import com.killua.data.utils.Exp.messageRes
import com.killua.data.utils.RepoResult
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.core.ObservableEmitter
import io.reactivex.rxjava3.core.Scheduler
import io.reactivex.rxjava3.core.Single
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.observers.DisposableSingleObserver
import io.reactivex.rxjava3.schedulers.Schedulers
import timber.log.Timber
import java.util.*
import javax.inject.Inject
import kotlin.math.abs

class DatasourceRepo @Inject constructor(
    private val clubsDao: ClubsDao,
    private val clubsServices: ClubsServices
) : IDatasourceRepo {
    private var compositeDisposable = CompositeDisposable()
    override fun getClub(id: String): Single<Club> {
        return clubsDao.getClub(id).map { it.toClub() }
    }


    @Throws(Exception::class)
    override fun getAndCheckClubs(
        @StringRes database_error: Int,
        @StringRes insert_failure: Int,
        @StringRes remove_failure: Int
    ): Observable<RepoResult<List<Club>>> {
        return Observable.create<RepoResult<List<Club>>> { emitter ->
            emitter.onNext(RepoResult.Loading)
            val clubs = arrayListOf<Club>()
            try {
                clubs.addAll(getClubsDb())
            } catch (e: Exp.DatabaseIsEmpty) {
                tryCatchApi(clubs, emitter, database_error, insert_failure, remove_failure)
            } catch (e: Exp.DatabaseNeedToUpdate) {
                tryCatchApi(clubs, emitter, database_error, insert_failure, remove_failure)
            } catch (e: Exp.DatabaseLoadError) {
                emitter.onError(e)
            } catch (e: Exception) {
                emitter.onError(e)
            } finally {
                if (clubs.isNotEmpty()) emitter.onNext(RepoResult.Success(clubs))
                emitter.onComplete()
            }
        }.subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
    }

    private fun tryCatchApi(
        clubs: ArrayList<Club>,
        emitter: ObservableEmitter<RepoResult<List<Club>>>,
        @StringRes database_error: Int,
        @StringRes insert_failure: Int,
        @StringRes remove_failure: Int
    ) {
        try {
            val clubsApi =
                getClubsApi(Schedulers.io(), database_error, insert_failure, remove_failure)
            clubs.addAll(clubsApi)
        } catch (e: Exp.ApiGettingError) {
            if (clubs.isNotEmpty())
                emitter.onNext(RepoResult.Success(clubs))
            else {
                emitter.onError(e)
            }
        }
    }

    @Throws(
        Exp.DatabaseLoadError::class, Exp.DatabaseIsEmpty::class
    )
    override fun getClubsDb(): List<Club> {
        var result: List<Club> = listOf()
        compositeDisposable.add(
            clubsDao.getAllClubs().subscribeWith(
                object : DisposableSingleObserver<List<ClubsEntity?>>() {
                    override fun onSuccess(list: List<ClubsEntity?>) {
                        if (list.isEmpty()) throw Exp.DatabaseIsEmpty
                        result = list.map { it?.toClub()!! }
                        list.firstOrNull().also { clubsEntity ->
                            if (clubsEntity != null) {
                                if (abs(
                                        clubsEntity.createDate.get(Calendar.DAY_OF_MONTH) - Calendar.getInstance()
                                            .get(Calendar.DAY_OF_MONTH)
                                    ) > 0
                                ) {
                                    throw Exp.DatabaseNeedToUpdate
                                }
                            }
                        }
                    }

                    override fun onError(e: Throwable) {
                        Timber.e(e, e.localizedMessage)
                        throw  Exp.DatabaseLoadError
                    }
                })
        )
        dispose()
        return result
    }

    @Throws(Exp.ApiGettingError::class)
    override fun getClubsApi(
        observeOn: Scheduler,
        @StringRes database_error: Int,
        @StringRes insert_failure: Int,
        @StringRes remove_failure: Int
    ): List<Club> {
        val clubs = arrayListOf<Club>()
        compositeDisposable.add(
            clubsServices.getAllClubs()
                .subscribeOn(Schedulers.io())
                .doOnSuccess { clubsApi ->
                    clubs.addAll(clubsApi.map { it.toClub() })
                    clubs.map { it.toEntity() }.toTypedArray().let {
                        updateClubsInDb(it, insert_failure, remove_failure)
                    }
                }
                .doOnError {
                    val ex = Exp.ApiGettingError
                    ex.initCause(it)
                    ex.messageRes = database_error
                    throw ex
                }
                .observeOn(Schedulers.io())
                .subscribe())
        return clubs
    }


    @Throws(Exception::class)
    override fun updateClubsInDb(
        club: Array<ClubsEntity>,
        @StringRes insert_failure: Int,
        @StringRes remove_failure: Int
    ) {
        try {
            removeAllClubDb(remove_failure)
            insertClubDb(arrayOf(*club), insert_failure)
            dispose()

        } catch (e: Exception) {
            Timber.wtf(e)
            throw e
        }
    }

    @Throws(Exp.DatabaseInsertError::class)
    override fun insertClubDb(club: Array<ClubsEntity>, @StringRes insert_failure: Int) {
        compositeDisposable.add(
            clubsDao.insertClub(*club).doOnComplete {
            }.subscribeOn(Schedulers.trampoline())
                .doOnError {
                    Timber.e(it, it.localizedMessage)
                    val ex = Exp.DatabaseInsertError
                    ex.initCause(it)
                    ex.messageRes = insert_failure
                    throw ex
                }
                .observeOn(Schedulers.io())
                .subscribe()
        )

    }

    @Throws(Exp.DatabaseRemovingError::class)
    override fun removeAllClubDb(@StringRes remove_faild: Int) {
        compositeDisposable.add(
            clubsDao.removeClubs()
                .subscribeOn(Schedulers.trampoline())
                .doOnError {
                    Timber.e(it, it.localizedMessage)
                    val ex = Exp.FailedInsertDatabase
                    ex.initCause(it)
                    ex.messageRes = remove_faild
                    throw ex
                }
                .observeOn(Schedulers.io())
                .subscribe()
        )

    }

    override fun dispose() {
        if (!compositeDisposable.isDisposed)
            compositeDisposable.dispose()
    }
}
