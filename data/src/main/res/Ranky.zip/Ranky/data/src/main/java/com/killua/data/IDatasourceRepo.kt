package com.killua.data


import androidx.annotation.StringRes
import com.killua.data.cashing.ClubsEntity
import com.killua.data.models.Club
import com.killua.data.utils.Exp
import com.killua.data.utils.RepoResult
import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.core.Scheduler
import io.reactivex.rxjava3.core.Single

interface IDatasourceRepo {

    fun getClub(id: String): Single<Club>

    fun getAndCheckClubs(
        @StringRes database_error: Int,
        @StringRes insert_failure: Int,
        @StringRes remove_failure: Int
    ): Observable<RepoResult<List<Club>>>

    @Throws(
        Exp.DatabaseLoadError::class
    )
    fun getClubsDb(): List<Club>?

    @Throws(Exp.ApiGettingError::class)
    fun getClubsApi(
        observeOn: Scheduler,
        @StringRes database_error: Int,
        @StringRes insert_failure: Int,
        @StringRes remove_failure: Int
    ): List<Club>

    @Throws(Exp.DatabaseUpdatingError::class)
    fun updateClubsInDb(
        club: Array<ClubsEntity>,
        @StringRes insert_failure: Int,
        @StringRes remove_failure: Int
    )

    @Throws(Exp.DatabaseInsertError::class)
    fun insertClubDb(club: Array<ClubsEntity>, insert_failure: Int)

    @Throws(Exp.DatabaseRemovingError::class)
    fun removeAllClubDb(remove_faild: Int)
    fun dispose()
}