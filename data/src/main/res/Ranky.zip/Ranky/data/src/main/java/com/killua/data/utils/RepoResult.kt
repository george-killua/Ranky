package com.killua.data.utils

sealed class RepoResult<out T : Any> {
    object Loading : RepoResult<Nothing>()
    data class Success<T : Any>(val data: T, val message: String? = null) : RepoResult<T>()
}



